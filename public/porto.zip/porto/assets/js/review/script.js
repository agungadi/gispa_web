// const editorOptions = {
//     modules: {
//       'toolbar': {
//         container: '#toolbar' }
//       },
//     placeholder: '  Compose an epic...',
//     theme: 'snow'  // or 'bubble'
//   };


//   const editor = new Quill('#editor-container', editorOptions);


//   editor.on('text-change', (delta, source) => {
//     console.log(editor.getText());

//   });


